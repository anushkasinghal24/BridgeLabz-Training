package com.healthclinic.health_clinic_app.service;

import com.healthclinic.health_clinic_app.dao.VisitDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.healthclinic.health_clinic_app.model.Prescription;
import com.healthclinic.health_clinic_app.config.DBConnection; // Utility class for JDBC connection

public class VisitService {

    private VisitDAO dao = new VisitDAO();

    // Use your DB utility class to get a connection
    private Connection getConnection() throws SQLException {
        return DBConnection.getConnection();
    }

    // ---------------------- UC-4.1: Record Patient Visit ----------------------
    public int recordVisit(int appointmentId, String diagnosis, String notes) {
    	
    	if (!appointmentExists(appointmentId)) {
    	    System.out.println("❌ Appointment does not exist!");
    	    
    	}


        int visitId = -1;

        String insertVisitSQL = """
            INSERT INTO visits (appointment_id, diagnosis, notes, visit_date)
            VALUES (?, ?, ?, CURDATE())
        """;

        String updateAppointmentSQL =
                "UPDATE appointments SET status = 'COMPLETED' WHERE appointment_id = ?";

        try (Connection conn = getConnection()) {

            conn.setAutoCommit(false); // start transaction

            try (PreparedStatement ps1 = conn.prepareStatement(
                    insertVisitSQL, PreparedStatement.RETURN_GENERATED_KEYS);
                 PreparedStatement ps2 = conn.prepareStatement(updateAppointmentSQL)) {

                // Insert visit
                ps1.setInt(1, appointmentId);
                ps1.setString(2, diagnosis);
                ps1.setString(3, notes);

                ps1.executeUpdate();

                // Get generated visit_id
                ResultSet rs = ps1.getGeneratedKeys();
                if (rs.next()) {
                    visitId = rs.getInt(1);
                }

                // Update appointment status
                ps2.setInt(1, appointmentId);
                ps2.executeUpdate();

                conn.commit(); // commit transaction

            } catch (SQLException e) {
                conn.rollback(); // rollback on error
                e.printStackTrace();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return visitId;
    }
    
    private boolean appointmentExists(int appointmentId) {
        String sql = "SELECT 1 FROM appointments WHERE appointment_id = ?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, appointmentId);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }



    // ---------------------- UC-4.2: View Patient Medical History ----------------------
    public void viewPatientHistory(int patientId) {
//        String sql = "SELECT v.visit_id, v.visit_date, v.diagnosis, p.medicine_name, p.dosage, p.duration " +
//                     "FROM visits v " +
//                     "LEFT JOIN prescriptions p ON v.visit_id = p.visit_id " +
//                     "WHERE v.patient_id = ? " +
//                     "ORDER BY v.visit_date DESC";
    	
    	String sql = "SELECT v.visit_id, v.visit_date, v.diagnosis, p.medicine_name, p.dosage, p.duration " +
                "FROM visits v " +
                "LEFT JOIN prescriptions p ON v.visit_id = p.visit_id " +
                "WHERE v.patientId = ? " +   // <-- use actual column name from your table
                "ORDER BY v.visit_date DESC";


        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, patientId);
            ResultSet rs = ps.executeQuery();

            System.out.println("Visit History for Patient ID: " + patientId);
            while (rs.next()) {
                System.out.println("Visit ID: " + rs.getInt("visit_id") +
                                   ", Date: " + rs.getDate("visit_date") +
                                   ", Diagnosis: " + rs.getString("diagnosis") +
                                   ", Medicine: " + rs.getString("medicine_name") +
                                   ", Dosage: " + rs.getString("dosage") +
                                   ", Duration: " + rs.getString("duration"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ---------------------- UC-4.3: Add Prescription (batch) ----------------------
    public void addPrescriptionToVisit(int visitId, List<Prescription> prescriptions) {
        String sql = "INSERT INTO prescriptions (visit_id, medicine_name, dosage, duration) VALUES (?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            conn.setAutoCommit(false);

            for (Prescription p : prescriptions) {
                ps.setInt(1, visitId);
                ps.setString(2, p.getMedicineName());
                ps.setString(3, p.getDosage());
                ps.setString(4, p.getDuration());
                ps.addBatch();
            }

            ps.executeBatch();
            conn.commit();

            System.out.println("Prescriptions added successfully for visit ID: " + visitId);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Optional: simple method to add default prescriptions (for demo)
    public void addPrescriptionToVisit(int visitId) {
        List<Prescription> list = new ArrayList<>();
        list.add(new Prescription("Paracetamol", "500mg", "5 days"));
        list.add(new Prescription("Amoxicillin", "250mg", "7 days"));

        addPrescriptionToVisit(visitId, list);
    }
}
