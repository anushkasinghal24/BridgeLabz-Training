package com.healthclinic.health_clinic_app.service;

import com.healthclinic.health_clinic_app.dao.PatientDAO;
import com.healthclinic.health_clinic_app.model.Patient;

import java.time.LocalDate;
import java.util.List;

public class PatientService {

    private PatientDAO dao;

    public PatientService() {
        dao = new PatientDAO();
    }

    // =========================
    // UC-1.1 Register Patient
    // =========================
    public void registerPatient(String name, LocalDate dob, String phone,
                                String email, String address, String bloodGroup) {

        Patient patient = new Patient(name, dob, phone, email, address, bloodGroup);

        boolean result = dao.registerPatient(patient);

        if (result) {
            System.out.println("Patient registration completed successfully.");
        } else {
            System.out.println("Patient registration failed.");
        }
    }


    // =========================
    // UC-1.2 Update Patient
    // =========================
    public void updatePatient(int id, String address, String phone) {

        boolean result = dao.updatePatient(id, address, phone);

        if (!result) {
            System.out.println("Update failed. Please check Patient ID.");
        }
    }


    // =========================
    // UC-1.3 Search Patient
    // =========================
    public void searchPatient(String keyword) {

        List<Patient> patients = dao.searchPatient(keyword);

        if (patients.isEmpty()) {
            System.out.println("No patient found.");
            return;
        }

        System.out.println("\n---- Search Results ----");

        for (Patient p : patients) {
            System.out.println("ID: " + p.getPatientId());
            System.out.println("Name: " + p.getName());
            System.out.println("DOB: " + p.getDob());
            System.out.println("Phone: " + p.getPhone());
            System.out.println("Email: " + p.getEmail());
            System.out.println("Address: " + p.getAddress());
            System.out.println("Blood Group: " + p.getBloodGroup());
            System.out.println("----------------------------");
        }
    }


    // =========================
    // UC-1.4 Visit History
    // =========================
    public void viewVisitHistory(int id) {
        dao.viewVisitHistory(id);
    }
}
