package com.healthclinic.health_clinic_app.dao;

public class BillingDAO {

}
