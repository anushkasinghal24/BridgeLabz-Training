////package com.healthclinic.health_clinic_app.service;
////import com.healthclinic.health_clinic_app.config.DBConnection;
////import java.sql.Connection;
////import java.sql.PreparedStatement;
////import java.sql.ResultSet;
////import java.sql.SQLException;
////import java.time.LocalDate;
////
////
////
////public class BillingService {
////
////    // Get JDBC connection
////    private Connection getConnection() throws SQLException {
////        return DBConnection.getConnection();
////    }
////
////    // UC-5.1: Generate Bill for a Visit
////    public int generateBill(int visitId, double additionalCharges) {
////        int billId = -1;
////
////        String sqlGetFee = "SELECT d.consultation_fee " +
////                           "FROM visits v JOIN doctors d ON v.doctor_id = d.doctor_id " +
////                           "WHERE v.visit_id = ?";
////
////        String sqlInsertBill = "INSERT INTO bills (visit_id, total_amount, bill_date, payment_status) " +
////                               "VALUES (?, ?, CURRENT_DATE, 'UNPAID')";
////
////        try (Connection conn = getConnection();
////             PreparedStatement psFee = conn.prepareStatement(sqlGetFee);
////             PreparedStatement psInsert = conn.prepareStatement(sqlInsertBill, PreparedStatement.RETURN_GENERATED_KEYS)) {
////
////            psFee.setInt(1, visitId);
////            ResultSet rs = psFee.executeQuery();
////            double total = 0;
////            if (rs.next()) {
////                total = rs.getDouble("consultation_fee") + additionalCharges;
////            }
////
////            psInsert.setInt(1, visitId);
////            psInsert.setDouble(2, total);
////            psInsert.executeUpdate();
////
////            ResultSet rsKey = psInsert.getGeneratedKeys();
////            if (rsKey.next()) {
////                billId = rsKey.getInt(1);
////            }
////
////        } catch (SQLException e) {
////            e.printStackTrace();
////        }
////
////        return billId;
////    }
////
////    // UC-5.2: Record Payment
////    public boolean recordPayment(int billId, String paymentMode) {
////        String sqlUpdateBill = "UPDATE bills SET payment_status='PAID', payment_date=CURRENT_DATE, payment_mode=? " +
////                               "WHERE bill_id = ?";
////        String sqlInsertTransaction = "INSERT INTO payment_transactions (bill_id, payment_date, payment_mode) VALUES (?, CURRENT_DATE, ?)";
////
////        try (Connection conn = getConnection();
////             PreparedStatement psUpdate = conn.prepareStatement(sqlUpdateBill);
////             PreparedStatement psTrans = conn.prepareStatement(sqlInsertTransaction)) {
////
////            conn.setAutoCommit(false);
////
////            psUpdate.setString(1, paymentMode);
////            psUpdate.setInt(2, billId);
////            psUpdate.executeUpdate();
////
////            psTrans.setInt(1, billId);
////            psTrans.setString(2, paymentMode);
////            psTrans.executeUpdate();
////
////            conn.commit();
////            return true;
////
////        } catch (SQLException e) {
////            e.printStackTrace();
////            return false;
////        }
////    }
////
////    // UC-5.3: View Outstanding Bills
////    public void viewOutstandingBills() {
////        String sql = "SELECT b.bill_id, b.visit_id, p.name AS patient_name, b.total_amount " +
////                     "FROM bills b JOIN visits v ON b.visit_id = v.visit_id " +
////                     "JOIN patients p ON v.patient_id = p.patient_id " +
////                     "WHERE b.payment_status='UNPAID'";
////
////        try (Connection conn = getConnection();
////             PreparedStatement ps = conn.prepareStatement(sql);
////             ResultSet rs = ps.executeQuery()) {
////
////            System.out.println("Outstanding Bills:");
////            while (rs.next()) {
////                System.out.println("Bill ID: " + rs.getInt("bill_id") +
////                                   ", Visit ID: " + rs.getInt("visit_id") +
////                                   ", Patient: " + rs.getString("patient_name") +
////                                   ", Amount: " + rs.getDouble("total_amount"));
////            }
////
////        } catch (SQLException e) {
////            e.printStackTrace();
////        }
////    }
////
////    // UC-5.4: Generate Revenue Report
////    public void generateRevenueReport(LocalDate startDate, LocalDate endDate) {
////        String sql = "SELECT d.doctor_id, d.name AS doctor_name, SUM(b.total_amount) AS revenue " +
////                     "FROM bills b " +
////                     "JOIN visits v ON b.visit_id = v.visit_id " +
////                     "JOIN doctors d ON v.doctor_id = d.doctor_id " +
////                     "WHERE b.payment_status='PAID' AND b.payment_date BETWEEN ? AND ? " +
////                     "GROUP BY d.doctor_id, d.name " +
////                     "HAVING SUM(b.total_amount) > 0";
////
////        try (Connection conn = getConnection();
////             PreparedStatement ps = conn.prepareStatement(sql)) {
////
////            ps.setDate(1, java.sql.Date.valueOf(startDate));
////            ps.setDate(2, java.sql.Date.valueOf(endDate));
////            ResultSet rs = ps.executeQuery();
////
////            System.out.println("Revenue Report from " + startDate + " to " + endDate);
////            while (rs.next()) {
////                System.out.println("Doctor ID: " + rs.getInt("doctor_id") +
////                                   ", Name: " + rs.getString("doctor_name") +
////                                   ", Revenue: " + rs.getDouble("revenue"));
////            }
////
////        } catch (SQLException e) {
////            e.printStackTrace();
////        }
////    }
////}
//
//
//
//package com.healthclinic.health_clinic_app.service;
//
//import com.healthclinic.health_clinic_app.config.DBConnection;
//import java.sql.*;
//import java.time.LocalDate;
//
//public class BillingService {
//
//    private Connection getConnection() throws SQLException {
//        return DBConnection.getConnection();
//    }
//
//    // ✅ UC-5.1: Generate Bill for a Visit
////    public int generateBill(int visitId, double additionalCharges) {
////        int billId = -1;
////
////        String sqlGetFee =
////                "SELECT d.consultation_fee " +
////                "FROM visits v " +
////                "JOIN appointments a ON v.appointment_id = a.appointment_id " +
////                "JOIN doctors d ON a.doctor_id = d.doctor_id " +
////                "WHERE v.visit_id = ?";
////
////        String sqlInsertBill =
////                "INSERT INTO bills (visit_id, total_amount, bill_date, payment_status) " +
////                "VALUES (?, ?, CURRENT_DATE, 'UNPAID')";
////
////        try (Connection conn = getConnection();
////             PreparedStatement psFee = conn.prepareStatement(sqlGetFee);
////             PreparedStatement psInsert = conn.prepareStatement(sqlInsertBill, Statement.RETURN_GENERATED_KEYS)) {
////
////            psFee.setInt(1, visitId);
////            ResultSet rs = psFee.executeQuery();
////
////            double total = 0;
////            if (rs.next()) {
////                total = rs.getDouble("consultation_fee") + additionalCharges;
////            } else {
////                System.out.println("Visit not found!");
////                return -1;
////            }
////
////            psInsert.setInt(1, visitId);
////            psInsert.setDouble(2, total);
////            psInsert.executeUpdate();
////
////            ResultSet rsKey = psInsert.getGeneratedKeys();
////            if (rsKey.next()) {
////                billId = rsKey.getInt(1);
////            }
////
////            System.out.println("Bill generated successfully. Bill ID: " + billId);
////
////        } catch (SQLException e) {
////            e.printStackTrace();
////        }
////
////        return billId;
////    }
//    
//    
//    
//
//    // ✅ UC-5.2: Record Payment
//    public boolean recordPayment(int billId, String paymentMode) {
//
//        String sqlUpdateBill =
//                "UPDATE bills SET payment_status='PAID', payment_date=CURRENT_DATE, payment_mode=? " +
//                "WHERE bill_id = ?";
//
//        String sqlInsertTransaction =
//                "INSERT INTO payment_transactions (bill_id, payment_date, payment_mode) " +
//                "VALUES (?, CURRENT_DATE, ?)";
//
//        try (Connection conn = getConnection();
//             PreparedStatement psUpdate = conn.prepareStatement(sqlUpdateBill);
//             PreparedStatement psTrans = conn.prepareStatement(sqlInsertTransaction)) {
//
//            conn.setAutoCommit(false);
//
//            psUpdate.setString(1, paymentMode);
//            psUpdate.setInt(2, billId);
//            psUpdate.executeUpdate();
//
//            psTrans.setInt(1, billId);
//            psTrans.setString(2, paymentMode);
//            psTrans.executeUpdate();
//
//            conn.commit();
//
//            System.out.println("Payment recorded successfully.");
//            return true;
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//            return false;
//        }
//    }
//
//    // ✅ UC-5.3: View Outstanding Bills
//    public void viewOutstandingBills() {
//
//        String sql =
//                "SELECT b.bill_id, b.visit_id, p.name AS patient_name, b.total_amount " +
//                "FROM bills b " +
//                "JOIN visits v ON b.visit_id = v.visit_id " +
//                "JOIN appointments a ON v.appointment_id = a.appointment_id " +
//                "JOIN patients p ON a.patient_id = p.patient_id " +
//                "WHERE b.payment_status='UNPAID'";
//
//        try (Connection conn = getConnection();
//             PreparedStatement ps = conn.prepareStatement(sql);
//             ResultSet rs = ps.executeQuery()) {
//
//            System.out.println("Outstanding Bills:");
//
//            while (rs.next()) {
//                System.out.println("Bill ID: " + rs.getInt("bill_id") +
//                        ", Visit ID: " + rs.getInt("visit_id") +
//                        ", Patient: " + rs.getString("patient_name") +
//                        ", Amount: " + rs.getDouble("total_amount"));
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//    // ✅ UC-5.4: Generate Revenue Report
//    public void generateRevenueReport(LocalDate startDate, LocalDate endDate) {
//
//        String sql =
//                "SELECT d.doctor_id, d.name AS doctor_name, SUM(b.total_amount) AS revenue " +
//                "FROM bills b " +
//                "JOIN visits v ON b.visit_id = v.visit_id " +
//                "JOIN appointments a ON v.appointment_id = a.appointment_id " +
//                "JOIN doctors d ON a.doctor_id = d.doctor_id " +
//                "WHERE b.payment_status='PAID' " +
//                "AND b.payment_date BETWEEN ? AND ? " +
//                "GROUP BY d.doctor_id, d.name " +
//                "HAVING SUM(b.total_amount) > 0";
//
//        try (Connection conn = getConnection();
//             PreparedStatement ps = conn.prepareStatement(sql)) {
//
//            ps.setDate(1, Date.valueOf(startDate));
//            ps.setDate(2, Date.valueOf(endDate));
//
//            ResultSet rs = ps.executeQuery();
//
//            System.out.println("Revenue Report from " + startDate + " to " + endDate);
//
//            while (rs.next()) {
//                System.out.println("Doctor ID: " + rs.getInt("doctor_id") +
//                        ", Name: " + rs.getString("doctor_name") +
//                        ", Revenue: " + rs.getDouble("revenue"));
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//}


package com.healthclinic.health_clinic_app.service;

import com.healthclinic.health_clinic_app.config.DBConnection;
import java.sql.*;
import java.time.LocalDate;

public class BillingService {

    private Connection getConnection() throws SQLException {
        return DBConnection.getConnection();
    }

    // ---------------- UC-5.1: Generate Bill for a Visit ----------------
    public int generateBill(int visitId, double additionalCharges) {
        int billId = -1;

        try (Connection conn = getConnection()) {

            conn.setAutoCommit(false);

            // 1️⃣ Check if bill already exists
            String sqlCheck = "SELECT bill_id, total_amount FROM bills WHERE visit_id = ?";
            PreparedStatement psCheck = conn.prepareStatement(sqlCheck);
            psCheck.setInt(1, visitId);
            ResultSet rsCheck = psCheck.executeQuery();

            if (rsCheck.next()) {
                // Bill already exists → update total_amount
                billId = rsCheck.getInt("bill_id");
                double existingTotal = rsCheck.getDouble("total_amount");

                String sqlUpdate = "UPDATE bills SET total_amount = ? WHERE bill_id = ?";
                PreparedStatement psUpdate = conn.prepareStatement(sqlUpdate);
                psUpdate.setDouble(1, existingTotal + additionalCharges);
                psUpdate.setInt(2, billId);
                psUpdate.executeUpdate();

                System.out.println("Existing bill updated. Bill ID: " + billId);
            } else {
                // 2️⃣ Fetch consultation fee from doctor
                String sqlGetFee = "SELECT d.consultation_fee " +
                                   "FROM visits v " +
                                   "JOIN appointments a ON v.appointment_id = a.appointment_id " +
                                   "JOIN doctors d ON a.doctor_id = d.doctor_id " +
                                   "WHERE v.visit_id = ?";
                PreparedStatement psFee = conn.prepareStatement(sqlGetFee);
                psFee.setInt(1, visitId);
                ResultSet rsFee = psFee.executeQuery();

                double total = additionalCharges;
                if (rsFee.next()) {
                    total += rsFee.getDouble("consultation_fee");
                } else {
                    System.out.println("Visit or Doctor not found for Visit ID: " + visitId);
                    conn.rollback();
                    return -1;
                }

                // 3️⃣ Insert new bill
                String sqlInsert = "INSERT INTO bills (visit_id, total_amount, payment_status, payment_date) " +
                                   "VALUES (?, ?, 'UNPAID', NULL)";
                PreparedStatement psInsert = conn.prepareStatement(sqlInsert, Statement.RETURN_GENERATED_KEYS);
                psInsert.setInt(1, visitId);
                psInsert.setDouble(2, total);
                psInsert.executeUpdate();

                ResultSet rsKey = psInsert.getGeneratedKeys();
                if (rsKey.next()) {
                    billId = rsKey.getInt(1);
                }

                System.out.println("New bill generated. Bill ID: " + billId);
            }

            conn.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return billId;
    }

    // ---------------- UC-5.2: Record Payment ----------------
    public boolean recordPayment(int billId, String paymentMode) {
        String sqlUpdateBill = "UPDATE bills SET payment_status='PAID', payment_date=CURRENT_DATE WHERE bill_id = ?";
        String sqlInsertTransaction = "INSERT INTO payment_transactions (bill_id, payment_mode, amount) " +
                                      "SELECT b.bill_id, ?, b.total_amount FROM bills b WHERE b.bill_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement psUpdate = conn.prepareStatement(sqlUpdateBill);
             PreparedStatement psTrans = conn.prepareStatement(sqlInsertTransaction)) {

            conn.setAutoCommit(false);

            psUpdate.setInt(1, billId);
            psUpdate.executeUpdate();

            psTrans.setString(1, paymentMode);
            psTrans.setInt(2, billId);
            psTrans.executeUpdate();

            conn.commit();
            System.out.println("Payment recorded successfully for Bill ID: " + billId);
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ---------------- UC-5.3: View Outstanding Bills ----------------
    public void viewOutstandingBills() {
        String sql = "SELECT b.bill_id, b.visit_id, p.name AS patient_name, b.total_amount " +
                     "FROM bills b " +
                     "JOIN visits v ON b.visit_id = v.visit_id " +
                     "JOIN appointments a ON v.appointment_id = a.appointment_id " +
                     "JOIN patients p ON a.patient_id = p.patient_id " +
                     "WHERE b.payment_status='UNPAID'";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("Outstanding Bills:");
            while (rs.next()) {
                System.out.println("Bill ID: " + rs.getInt("bill_id") +
                                   ", Visit ID: " + rs.getInt("visit_id") +
                                   ", Patient: " + rs.getString("patient_name") +
                                   ", Amount: " + rs.getDouble("total_amount"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ---------------- UC-5.4: Generate Revenue Report ----------------
    public void generateRevenueReport(LocalDate startDate, LocalDate endDate) {
        String sql = "SELECT d.doctor_id, d.name AS doctor_name, SUM(b.total_amount) AS revenue " +
                     "FROM bills b " +
                     "JOIN visits v ON b.visit_id = v.visit_id " +
                     "JOIN appointments a ON v.appointment_id = a.appointment_id " +
                     "JOIN doctors d ON a.doctor_id = d.doctor_id " +
                     "WHERE b.payment_status='PAID' AND b.payment_date BETWEEN ? AND ? " +
                     "GROUP BY d.doctor_id, d.name " +
                     "HAVING SUM(b.total_amount) > 0";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, java.sql.Date.valueOf(startDate));
            ps.setDate(2, java.sql.Date.valueOf(endDate));
            ResultSet rs = ps.executeQuery();

            System.out.println("Revenue Report from " + startDate + " to " + endDate);
            while (rs.next()) {
                System.out.println("Doctor ID: " + rs.getInt("doctor_id") +
                                   ", Name: " + rs.getString("doctor_name") +
                                   ", Revenue: " + rs.getDouble("revenue"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
