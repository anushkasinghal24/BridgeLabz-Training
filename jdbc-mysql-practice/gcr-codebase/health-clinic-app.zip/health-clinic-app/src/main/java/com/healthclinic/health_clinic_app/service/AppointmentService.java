package com.healthclinic.health_clinic_app.service;

import java.sql.*;
import static com.healthclinic.health_clinic_app.config.DBConnection.getConnection;

public class AppointmentService {

    // ==============================
    // UC-3.1 Book Appointment
    // ==============================
	// ==============================
	// UC-3.1 Book Appointment
	// ==============================
	public int bookAppointment(int patientId, int doctorId,
	                           String date, String time) {

	    if (!patientExists(patientId)) {
	        System.out.println("❌ Patient does not exist!");
	        return -1;
	    }

	    if (!doctorExists(doctorId)) {
	        System.out.println("❌ Doctor does not exist!");
	        return -1;
	    }

	    int appointmentId = -1;

	    String checkSlotSQL = """
	        SELECT COUNT(*) FROM appointments
	        WHERE doctor_id=? 
	        AND appointment_date=? 
	        AND appointment_time=? 
	        AND status='SCHEDULED'
	    """;

	    String insertSQL = """
	        INSERT INTO appointments
	        (patient_id, doctor_id, appointment_date, appointment_time, status)
	        VALUES (?, ?, ?, ?, 'SCHEDULED')
	    """;

	    try (Connection conn = getConnection()) {

	        // 🔍 Check slot availability
	        try (PreparedStatement ps = conn.prepareStatement(checkSlotSQL)) {

	            ps.setInt(1, doctorId);
	            ps.setDate(2, Date.valueOf(date));
	            ps.setTime(3, Time.valueOf(time + ":00"));

	            try (ResultSet rs = ps.executeQuery()) {
	                rs.next();

	                if (rs.getInt(1) > 0) {
	                    System.out.println("❌ Slot already booked!");
	                    return -1;
	                }
	            }
	        }

	        // ✅ Insert appointment
	        try (PreparedStatement ps = conn.prepareStatement(
	                insertSQL, Statement.RETURN_GENERATED_KEYS)) {

	            ps.setInt(1, patientId);
	            ps.setInt(2, doctorId);
	            ps.setDate(3, Date.valueOf(date));
	            ps.setTime(4, Time.valueOf(time + ":00"));

	            ps.executeUpdate();

	            try (ResultSet keys = ps.getGeneratedKeys()) {
	                if (keys.next()) {
	                    appointmentId = keys.getInt(1);
	                }
	            }

	            System.out.println("✅ Appointment booked successfully!");
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return appointmentId;
	}

 // Check if patient exists
	private boolean patientExists(int patientId) {
	    String sql = "SELECT 1 FROM patients WHERE patient_id = ?";
	    try (Connection con = getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {

	        ps.setInt(1, patientId);

	        try (ResultSet rs = ps.executeQuery()) {
	            return rs.next();
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false;
	}

	private boolean doctorExists(int doctorId) {
	    String sql = "SELECT 1 FROM doctors WHERE doctor_id = ?";
	    try (Connection con = getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {

	        ps.setInt(1, doctorId);

	        try (ResultSet rs = ps.executeQuery()) {
	            return rs.next();
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false;
	}


 // ==============================
 // View All Appointments
 // ==============================
 public void viewAppointments() {

     String sql = """
         SELECT a.appointment_id,
                p.name AS patient_name,
                d.name AS doctor_name,
                a.appointment_date,
                a.appointment_time,
                a.status
         FROM appointments a
         JOIN patients p ON a.patient_id = p.patient_id
         JOIN doctors d ON a.doctor_id = d.doctor_id
         ORDER BY a.appointment_date, a.appointment_time
     """;

     try (Connection conn = getConnection();
          PreparedStatement ps = conn.prepareStatement(sql);
          ResultSet rs = ps.executeQuery()) {

         System.out.println("\n📋 Appointment List:");
         System.out.println("------------------------------------------------");

         while (rs.next()) {

             System.out.println(
                 "ID: " + rs.getInt("appointment_id") +
                 " | Patient: " + rs.getString("patient_name") +
                 " | Doctor: " + rs.getString("doctor_name") +
                 " | Date: " + rs.getDate("appointment_date") +
                 " | Time: " + rs.getTime("appointment_time") +
                 " | Status: " + rs.getString("status")
             );
         }

     } catch (Exception e) {
         e.printStackTrace();
     }
     
     
 }


    // ==============================
    // UC-3.2 Check Doctor Availability
    // ==============================
    public void checkDoctorAvailability(int doctorId, String date) {

        String sql = """
            SELECT appointment_time, COUNT(*) AS total_booked
            FROM appointments
            WHERE doctor_id = ?
            AND appointment_date = ?
            AND status = 'SCHEDULED'
            GROUP BY appointment_time
        """;

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, doctorId);
            ps.setDate(2, Date.valueOf(date));

            ResultSet rs = ps.executeQuery();

            System.out.println("\n📅 Slot Availability:");
            boolean found = false;
            while (rs.next()) {
                System.out.println(
                        "Time: " + rs.getTime("appointment_time") +
                        " | Booked: " + rs.getInt("total_booked")
                );
            }
            if (!found) {
                System.out.println("✅ No appointments booked for this date.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ==============================
    // UC-3.3 Cancel Appointment
    // ==============================
    public void cancelAppointment(int appointmentId) {

        String sql = """
            UPDATE appointments
            SET status='CANCELLED'
            WHERE appointment_id=?
        """;

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, appointmentId);

            int rows = ps.executeUpdate();

            if (rows > 0)
                System.out.println("✅ Appointment cancelled.");
            else
                System.out.println("❌ Appointment not found.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ==============================
    // UC-3.4 Reschedule Appointment
    // ==============================
    public void rescheduleAppointment(int appointmentId,
                                      String newDate,
                                      String newTime) {

        String checkSQL = """
            SELECT COUNT(*) FROM appointments
            WHERE doctor_id = (
                SELECT doctor_id FROM appointments WHERE appointment_id = ?
            )
            AND appointment_date = ?
            AND appointment_time = ?
            AND status = 'SCHEDULED'
        """;

        String updateSQL = """
            UPDATE appointments
            SET appointment_date=?, appointment_time=?
            WHERE appointment_id=?
        """;

        try (Connection conn = getConnection()) {

            conn.setAutoCommit(false);

            // 🔍 Check new slot
            try (PreparedStatement ps = conn.prepareStatement(checkSQL)) {

                ps.setInt(1, appointmentId);
                ps.setDate(2, Date.valueOf(newDate));
                ps.setTime(3, Time.valueOf(newTime + ":00"));

                ResultSet rs = ps.executeQuery();
                rs.next();

                if (rs.getInt(1) > 0) {
                    System.out.println("❌ New slot already booked!");
                    conn.rollback();
                    return;
                }
            }

            // ✅ Update
            try (PreparedStatement ps = conn.prepareStatement(updateSQL)) {

                ps.setDate(1, Date.valueOf(newDate));
                ps.setTime(2, Time.valueOf(newTime + ":00"));
                ps.setInt(3, appointmentId);

                ps.executeUpdate();
            }

            conn.commit();
            System.out.println("✅ Appointment rescheduled successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        }
        
        try {
            Date.valueOf(newDate);
            Time.valueOf(newTime + ":00");
        } catch (IllegalArgumentException e) {
            System.out.println("❌ Invalid date or time format!");
            System.out.println("Date must be YYYY-MM-DD");
            System.out.println("Time must be HH:MM (24-hour format)");
            return;
        }
    }

    // ==============================
    // UC-3.5 View Daily Schedule
    // ==============================
    public void viewDailySchedule(String date) {

        String sql = """
            SELECT a.appointment_time,
                   p.name AS patient_name,
                   d.name AS doctor_name,
                   a.status
            FROM appointments a
            JOIN patients p ON a.patient_id = p.patient_id
            JOIN doctors d ON a.doctor_id = d.doctor_id
            WHERE a.appointment_date = ?
            ORDER BY a.appointment_time
        """;

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(date));

            ResultSet rs = ps.executeQuery();

            System.out.println("\n📋 Daily Schedule:");
            while (rs.next()) {

                System.out.println(
                        "Time: " + rs.getTime("appointment_time") +
                        " | Patient: " + rs.getString("patient_name") +
                        " | Doctor: " + rs.getString("doctor_name") +
                        " | Status: " + rs.getString("status")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
