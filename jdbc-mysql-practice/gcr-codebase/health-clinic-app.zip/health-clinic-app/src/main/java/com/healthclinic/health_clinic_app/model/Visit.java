package com.healthclinic.health_clinic_app.model;

public class Visit {

}
