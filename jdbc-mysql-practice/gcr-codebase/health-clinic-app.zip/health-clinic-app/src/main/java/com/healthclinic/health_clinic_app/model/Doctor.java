package com.healthclinic.health_clinic_app.model;

public class Doctor {

    private int doctorId;
    private String name;
    private int specialtyId;
    private String contact;
    private double consultationFee;
    private boolean isActive;

    // Default Constructor
    public Doctor() {}

    // Constructor for adding doctor
    public Doctor(String name, int specialtyId, String contact, double consultationFee) {
        this.name = name;
        this.specialtyId = specialtyId;
        this.contact = contact;
        this.consultationFee = consultationFee;
        this.isActive = true; // default active
    }

    // Full Constructor (optional, useful when fetching from DB)
    public Doctor(int doctorId, String name, int specialtyId,
                  String contact, double consultationFee, boolean isActive) {
        this.doctorId = doctorId;
        this.name = name;
        this.specialtyId = specialtyId;
        this.contact = contact;
        this.consultationFee = consultationFee;
        this.isActive = isActive;
    }

    // Getters
    public int getDoctorId() {
        return doctorId;
    }

    public String getName() {
        return name;
    }

    public int getSpecialtyId() {
        return specialtyId;
    }

    public String getContact() {
        return contact;
    }

    public double getConsultationFee() {
        return consultationFee;
    }

    public boolean isActive() {
        return isActive;
    }

    // Setters
    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSpecialtyId(int specialtyId) {
        this.specialtyId = specialtyId;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public void setConsultationFee(double consultationFee) {
        this.consultationFee = consultationFee;
    }

    public void setActive(boolean active) {
        isActive = active;
    }
}
