package com.healthclinic.health_clinic_app.service;

import com.healthclinic.health_clinic_app.dao.DoctorDAO;
import com.healthclinic.health_clinic_app.model.Doctor;

public class DoctorService {

    private DoctorDAO dao;

    public DoctorService() {
        dao = new DoctorDAO();
    }

    // =========================
    // UC-2.1 Add Doctor
    // =========================
    public void addDoctor(String name, String specialtyName, String contact, double fee) {

        if (name == null || name.isEmpty()) {
            System.out.println("Doctor name cannot be empty!");
            return;
        }

        if (fee <= 0) {
            System.out.println("Consultation fee must be positive!");
            return;
        }

        int specialtyId = dao.getSpecialtyIdByName(specialtyName);

        if (specialtyId == -1) {
            System.out.println("Specialty not found! Please add it first.");
            return;
        }

        Doctor doctor = new Doctor(name, specialtyId, contact, fee);

        boolean result = dao.addDoctor(doctor);

        if (result) {
            System.out.println("Doctor profile created successfully.");
        } else {
            System.out.println("Failed to create doctor profile.");
        }
    }


    // =========================
    // UC-2.2 Update Specialty
    // =========================
    public void updateSpecialty(int doctorId, String specialtyName) {

        int specialtyId = dao.getSpecialtyIdByName(specialtyName);

        if (specialtyId == -1) {
            System.out.println("Specialty not found!");
            return;
        }

        boolean result = dao.updateDoctorSpecialty(doctorId, specialtyId);

        if (!result) {
            System.out.println("Specialty update failed.");
        }
    }


    // =========================
    // UC-2.3 View Doctors by Specialty
    // =========================
    public void viewDoctorsBySpecialty(String specialtyName) {

        if (specialtyName == null || specialtyName.isEmpty()) {
            System.out.println("Specialty name cannot be empty!");
            return;
        }

        dao.viewDoctorsBySpecialty(specialtyName);
    }

    // =========================
    // UC-2.4 Deactivate Doctor
    // =========================
    public void deactivateDoctor(int doctorId) {

        boolean result = dao.deactivateDoctor(doctorId);

        if (!result) {
            System.out.println("Doctor deactivation failed.");
        }
    }
}
