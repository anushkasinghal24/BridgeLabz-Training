package com.healthclinic.health_clinic_app.dao;
import com.healthclinic.health_clinic_app.config.DBConnection;
import com.healthclinic.health_clinic_app.model.Doctor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DoctorDAO {

    // ==============================
    // UC-2.2 Update Doctor Specialty
    // ==============================
    public boolean updateDoctorSpecialty(int doctorId, int specialtyId) {

        String query = "UPDATE doctors SET specialty_id = ? WHERE doctor_id = ?";

        try (Connection conn = DBConnection.getConnection()) {

            conn.setAutoCommit(false); // Start transaction

            try (PreparedStatement stmt = conn.prepareStatement(query)) {

                stmt.setInt(1, specialtyId);
                stmt.setInt(2, doctorId);

                int rows = stmt.executeUpdate();

                if (rows > 0) {
                    conn.commit();
                    System.out.println("Specialty updated successfully!");
                    return true;
                } else {
                    conn.rollback();
                    System.out.println("Doctor not found!");
                    return false;
                }

            } catch (Exception e) {
                conn.rollback();
                throw e;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ==================================
    // UC-2.3 View Doctors By Specialty
    // ==================================
    public void viewDoctorsBySpecialty(String specialtyName) {

        String query = """
                SELECT d.doctor_id, d.name, d.contact, d.consultation_fee
                FROM doctors d
                JOIN specialties s ON d.specialty_id = s.specialty_id
                WHERE s.specialty_name = ? AND d.is_active = true
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, specialtyName);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                System.out.println("Doctor ID: " + rs.getInt("doctor_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Contact: " + rs.getString("contact"));
                System.out.println("Fee: " + rs.getDouble("consultation_fee"));
                System.out.println("----------------------");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ==================================
    // UC-2.4 Deactivate Doctor
    // ==================================
    public boolean deactivateDoctor(int doctorId) {

        String checkQuery = """
                SELECT COUNT(*) 
                FROM appointments 
                WHERE doctor_id = ? 
                AND appointment_date >= CURDATE()
                AND status = 'SCHEDULED'
                """;

        String updateQuery = "UPDATE doctors SET is_active = false WHERE doctor_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {

            checkStmt.setInt(1, doctorId);

            ResultSet rs = checkStmt.executeQuery();
            rs.next();

            int count = rs.getInt(1);

            if (count > 0) {
                System.out.println("Doctor has future appointments. Cannot deactivate.");
                return false;
            }

            try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {

                updateStmt.setInt(1, doctorId);
                updateStmt.executeUpdate();

                System.out.println("Doctor deactivated successfully.");
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    public int getSpecialtyIdByName(String specialtyName) {

        String query = "SELECT specialty_id FROM specialties WHERE specialty_name = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, specialtyName);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("specialty_id");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return -1; // not found
    }

    public boolean addDoctor(Doctor doctor) {

        String query = """
                INSERT INTO doctors (name, specialty_id, contact, consultation_fee, is_active)
                VALUES (?, ?, ?, ?, ?)
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, doctor.getName());
            stmt.setInt(2, doctor.getSpecialtyId());
            stmt.setString(3, doctor.getContact());
            stmt.setDouble(4, doctor.getConsultationFee());
            stmt.setBoolean(5, doctor.isActive());

            int rows = stmt.executeUpdate();

            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}
