package com.healthclinic.health_clinic_app.main;

import com.healthclinic.health_clinic_app.service.*;
import com.healthclinic.health_clinic_app.service.PatientService;
import com.healthclinic.health_clinic_app.service.DoctorService;
import com.healthclinic.health_clinic_app.service.VisitService;
import com.healthclinic.health_clinic_app.service.BillingService;
import com.healthclinic.health_clinic_app.service.AdminService;
import com.healthclinic.health_clinic_app.service.AppointmentService;
import com.healthclinic.health_clinic_app.model.Prescription;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HealthClinicApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        
        
        boolean running=true;

        PatientService patientService = new PatientService();
        DoctorService doctorService = new DoctorService();
        AppointmentService appointmentService = new AppointmentService();
        VisitService visitService = new VisitService();
        BillingService billingService = new BillingService();
        AdminService adminService = new AdminService();

        while (running) {

            System.out.println("\n========== HEALTH CLINIC SYSTEM ==========");

            System.out.println("\n--- PATIENT ---");
            System.out.println("1. Register Patient");
            System.out.println("2. Update Patient");
            System.out.println("3. Search Patient");
            System.out.println("4. View Visit History");

            System.out.println("\n--- DOCTOR ---");
            System.out.println("5. Add Doctor");
            System.out.println("6. Update Doctor Specialty");
            System.out.println("7. View Doctors by Specialty");
            System.out.println("8. Deactivate Doctor");

            System.out.println("\n--- APPOINTMENT ---");
            System.out.println("9. Book Appointment");
            System.out.println("10. View All Appointments");
            System.out.println("11. Check Doctor Availability");
            System.out.println("12. Cancel Appointment");
            System.out.println("13. Reschedule Appointment");
            System.out.println("14. View Daily Schedule");

            System.out.println("\n--- VISIT ---");
            System.out.println("15. Record Patient Visit");
            System.out.println("16. Add Prescription");

            System.out.println("\n--- BILLING ---");
            System.out.println("17. Generate Bill");
            System.out.println("18. Record Payment");
            System.out.println("19. View Outstanding Bills");
            System.out.println("20. Revenue Report");

            System.out.println("\n--- ADMIN ---");
            System.out.println("21. View Specialties");
            System.out.println("22. Add Specialty");
            System.out.println("23. Update Specialty");
            System.out.println("24. Delete Specialty");
            System.out.println("25. View Audit Logs");
            System.out.println("26. Perform Backup");

            System.out.println("0. Exit");

            System.out.print("\nEnter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                // ================= PATIENT =================

                case 1 -> {
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    System.out.print("DOB (YYYY-MM-DD): ");
                    LocalDate dob = LocalDate.parse(sc.nextLine());
                    System.out.print("Phone: ");
                    String phone = sc.nextLine();
                    System.out.print("Email: ");
                    String email = sc.nextLine();
                    System.out.print("Address: ");
                    String address = sc.nextLine();
                    System.out.print("Blood Group: ");
                    String blood = sc.nextLine();

                    patientService.registerPatient(name, dob, phone, email, address, blood);
                }

                case 2 -> {
                    System.out.print("Patient ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("New Address: ");
                    String addr = sc.nextLine();
                    System.out.print("New Phone: ");
                    String ph = sc.nextLine();
                    patientService.updatePatient(id, addr, ph);
                }

                case 3 -> {
                    System.out.print("Search keyword: ");
                    String keyword = sc.nextLine();
                    patientService.searchPatient(keyword);
                }

                case 4 -> {
                    System.out.print("Patient ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    visitService.viewPatientHistory(id);
                }

                // ================= DOCTOR =================

                case 5 -> {
                    System.out.print("Doctor Name: ");
                    String name = sc.nextLine();
                    System.out.print("Specialty: ");
                    String spec = sc.nextLine();
                    System.out.print("Contact: ");
                    String contact = sc.nextLine();
                    System.out.print("Fee: ");
                    double fee = sc.nextDouble();
                    sc.nextLine();
                    doctorService.addDoctor(name, spec, contact, fee);
                }

                case 6 -> {
                    System.out.print("Doctor ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("New Specialty: ");
                    String spec = sc.nextLine();
                    doctorService.updateSpecialty(id, spec);
                }

                case 7 -> {
                    System.out.print("Specialty: ");
                    String spec = sc.nextLine();
                    doctorService.viewDoctorsBySpecialty(spec);
                }

                case 8 -> {
                    System.out.print("Doctor ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    doctorService.deactivateDoctor(id);
                }

                // ================= APPOINTMENT =================

                case 9 -> {
                    System.out.print("Patient ID: ");
                    int p = sc.nextInt();
                    
                    System.out.print("Doctor ID: ");
                    int d = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Date (YYYY-MM-DD): ");
                    String date = sc.nextLine();
                    System.out.print("Time (HH:MM): ");
                    String time = sc.nextLine();
                    appointmentService.bookAppointment(p, d, date, time);
                }

                case 10 -> appointmentService.viewAppointments();

                case 11 -> {
                    System.out.print("Doctor ID: ");
                    int d = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Date (YYYY-MM-DD): ");
                    String date = sc.nextLine();
                    appointmentService.checkDoctorAvailability(d, date);
                }

                case 12 -> {
                    System.out.print("Appointment ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    appointmentService.cancelAppointment(id);
                }

                case 13 -> {
                    System.out.print("Appointment ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("New Date: ");
                    String newDate = sc.nextLine();
                    System.out.print("New Time: ");
                    String newTime = sc.nextLine();
                    appointmentService.rescheduleAppointment(id, newDate, newTime);
                }

                case 14 -> {
                    System.out.print("Date (YYYY-MM-DD): ");
                    String date = sc.nextLine();
                    appointmentService.viewDailySchedule(date);
                }

                // ================= VISIT =================

                case 15 -> {
                    System.out.print("Appointment ID: ");
                    int apId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Diagnosis: ");
                    String diagnosis = sc.nextLine();
                    System.out.print("Notes: ");
                    String notes = sc.nextLine();
                    visitService.recordVisit(apId, diagnosis, notes);
                }

                case 16 -> {
                    System.out.print("Visit ID: ");
                    int visitId = sc.nextInt();
                    sc.nextLine();
                    List<Prescription> list = new ArrayList<>();
                    while (true) {
                        System.out.print("Medicine (or done): ");
                        String med = sc.nextLine();
                        if (med.equalsIgnoreCase("done")) break;
                        System.out.print("Dosage: ");
                        String dosage = sc.nextLine();
                        System.out.print("Duration: ");
                        String duration = sc.nextLine();
                        list.add(new Prescription(med, dosage, duration));
                    }
                    visitService.addPrescriptionToVisit(visitId, list);
                }

                // ================= BILLING =================

                case 17 -> {
                    System.out.print("Visit ID: ");
                    int visitId = sc.nextInt();
                    System.out.print("Additional Charges: ");
                    double ch = sc.nextDouble();
                    sc.nextLine();
                    billingService.generateBill(visitId, ch);
                }

                case 18 -> {
                    System.out.print("Bill ID: ");
                    int billId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Payment Mode: ");
                    String mode = sc.nextLine();
                    billingService.recordPayment(billId, mode);
                }

                case 19 -> billingService.viewOutstandingBills();

                case 20 -> {
                    System.out.print("Start Date: ");
                    LocalDate s = LocalDate.parse(sc.nextLine());
                    System.out.print("End Date: ");
                    LocalDate e = LocalDate.parse(sc.nextLine());
                    billingService.generateRevenueReport(s, e);
                }

                // ADMIN 

                case 21 -> adminService.viewSpecialties();
                case 22 -> {
                    System.out.print("Specialty Name: ");
                    adminService.addSpecialty(sc.nextLine());
                }
                case 23 -> {
                    System.out.print("Specialty ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("New Name: ");
                    adminService.updateSpecialty(id, sc.nextLine());
                }
                case 24 -> {
                    System.out.print("Specialty ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    adminService.deleteSpecialty(id);
                }
                case 25 ->adminService.viewAuditLogs();

                case 26 -> adminService.performBackup();

                case 0 -> {
                    System.out.println("Exiting...");
                    // sc.close();  // optional, JVM exit me auto close ho jayega
                    running=false;// terminate program
                    System.exit(0);
                }
 // force terminate JVM
                



                default -> System.out.println("Invalid choice!");
            }
           
           
        }
        
        sc.close();
        
        
    }
}
