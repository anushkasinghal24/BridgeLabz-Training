package com.healthclinic.health_clinic_app.dao;

import com.healthclinic.health_clinic_app.config.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;

public class AppointmentDAO {

    // =========================================
    // UC-3.1 Book Appointment
    // =========================================
    public boolean bookAppointment(int patientId, int doctorId,
                                   LocalDate date, LocalTime time) {

        String checkQuery = """
                SELECT COUNT(*) FROM appointments
                WHERE doctor_id = ?
                AND appointment_date = ?
                AND appointment_time = ?
                AND status = 'SCHEDULED'
                """;

        String insertQuery = """
                INSERT INTO appointments
                (patient_id, doctor_id, appointment_date, appointment_time, status)
                VALUES (?, ?, ?, ?, 'SCHEDULED')
                """;

        try (Connection conn = DBConnection.getConnection()) {

            // Check slot availability
            try (PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {

                checkStmt.setInt(1, doctorId);
                checkStmt.setDate(2, Date.valueOf(date));
                checkStmt.setTime(3, Time.valueOf(time));

                ResultSet rs = checkStmt.executeQuery();
                rs.next();

                if (rs.getInt(1) > 0) {
                    System.out.println("Slot already booked!");
                    return false;
                }
            }

            // Insert appointment
            try (PreparedStatement insertStmt = conn.prepareStatement(insertQuery)) {

                insertStmt.setInt(1, patientId);
                insertStmt.setInt(2, doctorId);
                insertStmt.setDate(3, Date.valueOf(date));
                insertStmt.setTime(4, Time.valueOf(time));

                insertStmt.executeUpdate();
                System.out.println("Appointment booked successfully.");
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // =========================================
    // UC-3.2 Check Doctor Availability
    // =========================================
    public void checkDoctorAvailability(int doctorId, LocalDate date) {

        String query = """
                SELECT appointment_time, COUNT(*) as total
                FROM appointments
                WHERE doctor_id = ?
                AND appointment_date = ?
                AND status = 'SCHEDULED'
                GROUP BY appointment_time
                ORDER BY appointment_time
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, doctorId);
            stmt.setDate(2, Date.valueOf(date));

            ResultSet rs = stmt.executeQuery();

            System.out.println("Doctor Availability on " + date);
            while (rs.next()) {
                System.out.println("Time: " + rs.getTime("appointment_time")
                        + " | Bookings: " + rs.getInt("total"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // =========================================
    // UC-3.3 Cancel Appointment (Transaction)
    // =========================================
    public boolean cancelAppointment(int appointmentId) {

        String updateQuery = """
                UPDATE appointments
                SET status = 'CANCELLED'
                WHERE appointment_id = ?
                """;

        String auditQuery = """
                INSERT INTO appointment_audit
                (appointment_id, action, action_time)
                VALUES (?, 'CANCELLED', NOW())
                """;

        try (Connection conn = DBConnection.getConnection()) {

            conn.setAutoCommit(false);

            try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
                 PreparedStatement auditStmt = conn.prepareStatement(auditQuery)) {

                updateStmt.setInt(1, appointmentId);
                int rows = updateStmt.executeUpdate();

                if (rows == 0) {
                    conn.rollback();
                    System.out.println("Appointment not found.");
                    return false;
                }

                auditStmt.setInt(1, appointmentId);
                auditStmt.executeUpdate();

                conn.commit();
                System.out.println("Appointment cancelled successfully.");
                return true;

            } catch (Exception e) {
                conn.rollback();
                throw e;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // =========================================
    // UC-3.4 Reschedule Appointment
    // =========================================
    public boolean rescheduleAppointment(int appointmentId,
                                         int newDoctorId,
                                         LocalDate newDate,
                                         LocalTime newTime) {

        String checkQuery = """
                SELECT COUNT(*) FROM appointments
                WHERE doctor_id = ?
                AND appointment_date = ?
                AND appointment_time = ?
                AND status = 'SCHEDULED'
                AND appointment_id != ?
                """;

        String updateQuery = """
                UPDATE appointments
                SET doctor_id = ?, appointment_date = ?, appointment_time = ?
                WHERE appointment_id = ?
                """;

        try (Connection conn = DBConnection.getConnection()) {

            conn.setAutoCommit(false);

            // Check availability excluding same appointment
            try (PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {

                checkStmt.setInt(1, newDoctorId);
                checkStmt.setDate(2, Date.valueOf(newDate));
                checkStmt.setTime(3, Time.valueOf(newTime));
                checkStmt.setInt(4, appointmentId);

                ResultSet rs = checkStmt.executeQuery();
                rs.next();

                if (rs.getInt(1) > 0) {
                    conn.rollback();
                    System.out.println("New slot unavailable.");
                    return false;
                }
            }

            // Update appointment
            try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {

                updateStmt.setInt(1, newDoctorId);
                updateStmt.setDate(2, Date.valueOf(newDate));
                updateStmt.setTime(3, Time.valueOf(newTime));
                updateStmt.setInt(4, appointmentId);

                int rows = updateStmt.executeUpdate();

                if (rows == 0) {
                    conn.rollback();
                    return false;
                }
            }

            conn.commit();
            System.out.println("Appointment rescheduled successfully.");
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // =========================================
    // UC-3.5 View Daily Schedule
    // =========================================
    public void viewDailySchedule(LocalDate date) {

        String query = """
                SELECT a.appointment_time,
                       p.name AS patient_name,
                       d.name AS doctor_name,
                       a.status
                FROM appointments a
                JOIN patients p ON a.patient_id = p.patient_id
                JOIN doctors d ON a.doctor_id = d.doctor_id
                WHERE a.appointment_date = ?
                ORDER BY a.appointment_time
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setDate(1, Date.valueOf(date));

            ResultSet rs = stmt.executeQuery();

            System.out.println("Daily Schedule for: " + date);
            while (rs.next()) {
                System.out.println(
                        rs.getTime("appointment_time") +
                                " | Patient: " + rs.getString("patient_name") +
                                " | Doctor: " + rs.getString("doctor_name") +
                                " | Status: " + rs.getString("status")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
