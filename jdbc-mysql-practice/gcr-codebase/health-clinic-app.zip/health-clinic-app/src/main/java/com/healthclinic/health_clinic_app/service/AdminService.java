//package com.healthclinic.health_clinic_app.service;
//
//import java.sql.*;
//import java.time.LocalDate;
//import java.util.Scanner;
//import com.healthclinic.health_clinic_app.config.DBConnection;
//
//public class AdminService {
//
//    private Connection getConnection() throws SQLException {
//        return DBConnection.getConnection();
//    }
//
//    // ---------------- UC-6.1: Manage Specialty Lookup ----------------
//    public void addSpecialty(String name) {
//        String sql = "INSERT INTO specialties (name) VALUES (?)";
//        try (Connection conn = getConnection();
//             PreparedStatement ps = conn.prepareStatement(sql)) {
//            ps.setString(1, name);
//            ps.executeUpdate();
//            System.out.println("Specialty added successfully.");
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//    public void updateSpecialty(int id, String newName) {
//        String sql = "UPDATE specialties SET name = ? WHERE specialty_id = ?";
//        try (Connection conn = getConnection();
//             PreparedStatement ps = conn.prepareStatement(sql)) {
//            ps.setString(1, newName);
//            ps.setInt(2, id);
//            ps.executeUpdate();
//            System.out.println("Specialty updated successfully.");
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//    public void deleteSpecialty(int id) {
//        String sqlCheck = "SELECT COUNT(*) AS count FROM doctors WHERE specialty_id = ?";
//        String sqlDelete = "DELETE FROM specialties WHERE specialty_id = ?";
//
//        try (Connection conn = getConnection();
//             PreparedStatement psCheck = conn.prepareStatement(sqlCheck);
//             PreparedStatement psDelete = conn.prepareStatement(sqlDelete)) {
//
//            psCheck.setInt(1, id);
//            ResultSet rs = psCheck.executeQuery();
//            if (rs.next() && rs.getInt("count") > 0) {
//                System.out.println("Cannot delete specialty: doctors exist with this specialty.");
//                return;
//            }
//
//            psDelete.setInt(1, id);
//            psDelete.executeUpdate();
//            System.out.println("Specialty deleted successfully.");
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//    public void viewSpecialties() {
//        String sql = "SELECT * FROM specialties";
//        try (Connection conn = getConnection();
//             PreparedStatement ps = conn.prepareStatement(sql);
//             ResultSet rs = ps.executeQuery()) {
//
//            System.out.println("Specialty List:");
//            while (rs.next()) {
//                System.out.println("ID: " + rs.getInt("specialty_id") + ", Name: " + rs.getString("specialty_name"));
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//    // ---------------- UC-6.2: Database Backup Trigger ----------------
//    public void performBackup() {
//        try (Connection conn = getConnection()) {
//            DatabaseMetaData meta = conn.getMetaData();
//            ResultSet tables = meta.getTables(null, null, "%", new String[] {"TABLE"});
//
//            System.out.println("Performing backup of critical tables...");
//            while (tables.next()) {
//                String tableName = tables.getString("TABLE_NAME");
//                // For simplicity, just print table names — you can extend this to export CSV
//                System.out.println("Backing up table: " + tableName);
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//    // ---------------- UC-6.3: View System Audit Logs ----------------
//    public void viewAuditLogs(String user, String tableName, LocalDate fromDate, LocalDate toDate) {
//    	String sql = "SELECT * FROM audit_logs";
//
//
//        if (user != null && !user.isEmpty()) sql += " AND user_name = ?";
//        if (tableName != null && !tableName.isEmpty()) sql += " AND table_name = ?";
//        if (fromDate != null) sql += " AND timestamp >= ?";
//        if (toDate != null) sql += " AND timestamp <= ?";
//
//        try (Connection conn = getConnection();
//             PreparedStatement ps = conn.prepareStatement(sql)) {
//
//            int index = 1;
//            if (user != null && !user.isEmpty()) ps.setString(index++, user);
//            if (tableName != null && !tableName.isEmpty()) ps.setString(index++, tableName);
//            if (fromDate != null) ps.setDate(index++, java.sql.Date.valueOf(fromDate));
//            if (toDate != null) ps.setDate(index++, java.sql.Date.valueOf(toDate));
//
//            ResultSet rs = ps.executeQuery();
//            System.out.println("Audit Logs:");
//            while (rs.next()) {
//                System.out.println("ID: " + rs.getInt("log_id") +
//                                   ", User: " + rs.getString("user_name") +
//                                   ", Table: " + rs.getString("table_name") +
//                                   ", Action: " + rs.getString("action_type") +
//                                   ", Timestamp: " + rs.getTimestamp("timestamp"));
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//}


package com.healthclinic.health_clinic_app.service;

import java.sql.*;
import java.time.LocalDate;
import com.healthclinic.health_clinic_app.config.DBConnection;

public class AdminService {

    private Connection getConnection() throws SQLException {
        return DBConnection.getConnection();
    }

    // ---------------- UC-6.1: Manage Specialty Lookup ----------------

    public void addSpecialty(String name) {
        String sql = "INSERT INTO specialties (specialty_name) VALUES (?)";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.executeUpdate();
            System.out.println("Specialty added successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateSpecialty(int id, String newName) {
        String sql = "UPDATE specialties SET specialty_name = ? WHERE specialty_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, newName);
            ps.setInt(2, id);
            ps.executeUpdate();
            System.out.println("Specialty updated successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteSpecialty(int id) {
        String sqlCheck = "SELECT COUNT(*) AS count FROM doctors WHERE specialty_id = ?";
        String sqlDelete = "DELETE FROM specialties WHERE specialty_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement psCheck = conn.prepareStatement(sqlCheck);
             PreparedStatement psDelete = conn.prepareStatement(sqlDelete)) {

            psCheck.setInt(1, id);
            ResultSet rs = psCheck.executeQuery();

            if (rs.next() && rs.getInt("count") > 0) {
                System.out.println("Cannot delete specialty: doctors exist with this specialty.");
                return;
            }

            psDelete.setInt(1, id);
            psDelete.executeUpdate();
            System.out.println("Specialty deleted successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewSpecialties() {
        String sql = "SELECT * FROM specialties";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("========== SPECIALTY LIST ==========");

            while (rs.next()) {
                System.out.println(
                        "ID: " + rs.getInt("specialty_id") +
                        ", Name: " + rs.getString("specialty_name")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ---------------- UC-6.2: Database Backup ----------------

    public void performBackup() {
        try (Connection conn = getConnection()) {

            DatabaseMetaData meta = conn.getMetaData();
            ResultSet tables = meta.getTables(null, null, "%", new String[]{"TABLE"});

            System.out.println("========== BACKUP STARTED ==========");

            while (tables.next()) {
                String tableName = tables.getString("TABLE_NAME");
                System.out.println("Backing up table: " + tableName);
            }

            System.out.println("Backup completed successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ---------------- UC-6.3: View System Audit Logs ----------------

    public void viewAuditLogs() {

        String sql = "SELECT * FROM audit_logs ORDER BY action_time DESC";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("========== AUDIT LOGS ==========");

            boolean hasData = false;

            while (rs.next()) {
                hasData = true;

                System.out.println(
                        "Audit ID: " + rs.getInt("audit_id") +
                        ", Table: " + rs.getString("table_name") +
                        ", Action: " + rs.getString("action_type") +
                        ", Record ID: " + rs.getInt("record_id") +
                        ", Time: " + rs.getTimestamp("action_time")
                );
            }

            if (!hasData) {
                System.out.println("No audit logs found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

