package com.healthclinic.health_clinic_app.dao;

import com.healthclinic.health_clinic_app.config.DBConnection;
import com.healthclinic.health_clinic_app.model.Patient;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO {

    // =========================
    // UC-1.1 Register Patient
    // =========================
    public boolean registerPatient(Patient patient) {

        String checkQuery = "SELECT * FROM patients WHERE phone = ? OR email = ?";
        String insertQuery = "INSERT INTO patients(name,dob,phone,email,address,blood_group) VALUES (?,?,?,?,?,?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {

            checkStmt.setString(1, patient.getPhone());
            checkStmt.setString(2, patient.getEmail());

            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                System.out.println("Patient already exists with same phone/email!");
                return false;
            }

            try (PreparedStatement insertStmt = conn.prepareStatement(insertQuery)) {

                insertStmt.setString(1, patient.getName());

                // If Patient model uses LocalDate
                insertStmt.setDate(2, java.sql.Date.valueOf(patient.getDob()));

                insertStmt.setString(3, patient.getPhone());
                insertStmt.setString(4, patient.getEmail());
                insertStmt.setString(5, patient.getAddress());
                insertStmt.setString(6, patient.getBloodGroup());

                insertStmt.executeUpdate();
                System.out.println("Patient Registered Successfully!");
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }   // ✅ METHOD CLOSED PROPERLY HERE



    // =========================
    // UC-1.2 Update Patient
    // =========================
    public boolean updatePatient(int patientId, String address, String phone) {

        String query = "UPDATE patients SET address = ?, phone = ? WHERE patient_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, address);
            stmt.setString(2, phone);
            stmt.setInt(3, patientId);

            int rows = stmt.executeUpdate();

            if (rows > 0) {
                System.out.println("Patient updated successfully!");
                return true;
            } else {
                System.out.println("Patient not found!");
                return false;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }



    // =========================
    // UC-1.3 Search Patient
    // =========================
    public List<Patient> searchPatient(String keyword) {

        List<Patient> list = new ArrayList<>();

        String query = "SELECT * FROM patients WHERE name LIKE ? OR phone = ? OR patient_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, "%" + keyword + "%");
            stmt.setString(2, keyword);

            try {
                stmt.setInt(3, Integer.parseInt(keyword));
            } catch (Exception e) {
                stmt.setInt(3, 0);
            }

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Patient p = new Patient();

                p.setPatientId(rs.getInt("patient_id"));
                p.setName(rs.getString("name"));

                // If using LocalDate in model
                p.setDob(rs.getDate("dob").toLocalDate());

                p.setPhone(rs.getString("phone"));
                p.setEmail(rs.getString("email"));
                p.setAddress(rs.getString("address"));
                p.setBloodGroup(rs.getString("blood_group"));

                list.add(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }



    // =========================
    // UC-1.4 View Visit History
    // =========================
    public void viewVisitHistory(int patientId) {

        String query = """
                SELECT v.visit_id, v.diagnosis, v.visit_date,
                       d.name AS doctor_name
                FROM visits v
                JOIN appointments a ON v.appointment_id = a.appointment_id
                JOIN doctors d ON a.doctor_id = d.doctor_id
                WHERE a.patient_id = ?
                ORDER BY v.visit_date ASC
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, patientId);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                System.out.println("Visit ID: " + rs.getInt("visit_id"));
                System.out.println("Doctor: " + rs.getString("doctor_name"));
                System.out.println("Diagnosis: " + rs.getString("diagnosis"));
                System.out.println("Visit Date: " + rs.getDate("visit_date"));
                System.out.println("--------------------------");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

} 