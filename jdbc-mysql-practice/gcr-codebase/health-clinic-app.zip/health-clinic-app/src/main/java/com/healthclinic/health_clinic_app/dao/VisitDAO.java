package com.healthclinic.health_clinic_app.dao;

import com.healthclinic.health_clinic_app.config.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.List;

public class VisitDAO {

    // =========================================
    // UC-4.1 Record Patient Visit
    // =========================================
    public boolean recordVisit(int appointmentId,
                               int patientId,
                               int doctorId,
                               String diagnosis,
                               String notes) {

        String insertVisitQuery = """
                INSERT INTO visits
                (appointment_id, patient_id, doctor_id, visit_date, diagnosis, notes)
                VALUES (?, ?, ?, CURDATE(), ?, ?)
                """;

        String updateAppointmentQuery = """
                UPDATE appointments
                SET status = 'COMPLETED'
                WHERE appointment_id = ?
                """;

        try (Connection conn = DBConnection.getConnection()) {

            conn.setAutoCommit(false);

            int generatedVisitId;

            // Insert visit
            try (PreparedStatement visitStmt =
                         conn.prepareStatement(insertVisitQuery, Statement.RETURN_GENERATED_KEYS)) {

                visitStmt.setInt(1, appointmentId);
                visitStmt.setInt(2, patientId);
                visitStmt.setInt(3, doctorId);
                visitStmt.setString(4, diagnosis);
                visitStmt.setString(5, notes);

                visitStmt.executeUpdate();

                ResultSet rs = visitStmt.getGeneratedKeys();
                rs.next();
                generatedVisitId = rs.getInt(1);
            }

            // Update appointment
            try (PreparedStatement updateStmt =
                         conn.prepareStatement(updateAppointmentQuery)) {

                updateStmt.setInt(1, appointmentId);
                updateStmt.executeUpdate();
            }

            conn.commit();
            System.out.println("Visit recorded successfully.");
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    // =========================================
    // UC-4.2 View Medical History
    // =========================================
    public void viewMedicalHistory(int patientId) {

        String query = """
                SELECT v.visit_id,
                       v.visit_date,
                       v.diagnosis,
                       v.notes,
                       p.medicine_name,
                       p.dosage,
                       p.duration
                FROM visits v
                LEFT JOIN prescriptions p ON v.visit_id = p.visit_id
                JOIN appointments a ON v.appointment_id = a.appointment_id
                WHERE v.patient_id = ?
                ORDER BY v.visit_date DESC
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, patientId);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                System.out.println("Visit ID: " + rs.getInt("visit_id"));
                System.out.println("Date: " + rs.getDate("visit_date"));
                System.out.println("Diagnosis: " + rs.getString("diagnosis"));
                System.out.println("Notes: " + rs.getString("notes"));
                System.out.println("Medicine: " + rs.getString("medicine_name"));
                System.out.println("Dosage: " + rs.getString("dosage"));
                System.out.println("Duration: " + rs.getString("duration"));
                System.out.println("----------------------------------");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // =========================================
    // UC-4.3 Add Prescription (Batch Insert)
    // =========================================
    public boolean addPrescriptions(int visitId,
                                    List<String[]> prescriptions) {

        String query = """
                INSERT INTO prescriptions
                (visit_id, medicine_name, dosage, duration)
                VALUES (?, ?, ?, ?)
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            for (String[] pres : prescriptions) {

                stmt.setInt(1, visitId);
                stmt.setString(2, pres[0]); // medicine name
                stmt.setString(3, pres[1]); // dosage
                stmt.setString(4, pres[2]); // duration

                stmt.addBatch();
            }

            stmt.executeBatch();

            System.out.println("Prescriptions added successfully.");
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}


