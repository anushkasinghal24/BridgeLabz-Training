package com.healthclinic.health_clinic_app.model;

public class Prescription {
    private String medicineName;
    private String dosage;
    private String duration;

    public Prescription(String medicineName, String dosage, String duration) {
        this.medicineName = medicineName;
        this.dosage = dosage;
        this.duration = duration;
    }

    public String getMedicineName() { return medicineName; }
    public String getDosage() { return dosage; }
    public String getDuration() { return duration; }
}
